const express = require('express');
const router = express.Router();
const { addToQueue, getQueueStatus, clearQueue } = require('../queue');

// Single message bhejo
router.post('/send', (req, res) => {
  const { phone, message } = req.body;

  if (!phone || !message) {
    return res.status(400).json({ error: 'phone and message required' });
  }

  const result = addToQueue(req.userId, [{ phone, message }]);

  if (result.error) return res.status(429).json(result);
  res.json({ success: true, ...result });
});

// Bulk messages bhejo (array of {phone, message})
router.post('/send-bulk', (req, res) => {
  const { messages } = req.body;

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'messages array required' });
  }

  // Validate each message
  for (const msg of messages) {
    if (!msg.phone || !msg.message) {
      return res.status(400).json({ error: 'Each message needs phone and message fields' });
    }
  }

  const result = addToQueue(req.userId, messages);

  if (result.error) return res.status(429).json(result);
  res.json({
    success: true,
    ...result,
    info: `Sending in batches of 20 with 10-15s delay between batches`
  });
});

// Queue status check
router.get('/queue-status', (req, res) => {
  const status = getQueueStatus(req.userId);
  res.json(status);
});

// Queue clear karo
router.delete('/clear-queue', (req, res) => {
  const result = clearQueue(req.userId);
  res.json(result);
});

module.exports = router;
