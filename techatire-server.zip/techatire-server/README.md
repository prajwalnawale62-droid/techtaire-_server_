# TechAtire WhatsApp Server 🚀

Multi-user WhatsApp message server with QR authentication, delay system, and Railway deployment.

## Features
- ✅ Multiple users (7+) with isolated sessions
- ✅ Per-user private QR codes (Socket.io rooms)
- ✅ Delay system: 20 msg → 10-15s delay → 20 msg...
- ✅ 3000 messages/day per user limit
- ✅ JWT authentication
- ✅ Railway ready

---

## Railway Deployment

### Step 1: GitHub par push karo
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin YOUR_GITHUB_REPO
git push -u origin main
```

### Step 2: Railway setup
1. railway.app par jao
2. "New Project" → "Deploy from GitHub repo"
3. Repo select karo
4. Environment Variables add karo:
   - `JWT_SECRET` = koi bhi strong string
   - `ADMIN_KEY` = admin password

### Step 3: Deploy!
Railway automatically deploy karega.

---

## API Documentation

### Base URL: `https://your-app.railway.app`

---

### 1. Register User
```http
POST /api/session/register
Content-Type: application/json

{
  "userId": "user1",
  "password": "mypassword"
}
```
Response:
```json
{
  "token": "eyJ...",
  "userId": "user1"
}
```

---

### 2. Login
```http
POST /api/session/login
Content-Type: application/json

{
  "userId": "user1",
  "password": "mypassword"
}
```

---

### 3. Connect WhatsApp (QR generate)
```http
POST /api/session/connect
Authorization: Bearer YOUR_TOKEN
```

**Socket.io se QR receive karo:**
```javascript
import { io } from 'socket.io-client';

const socket = io('https://your-app.railway.app');

// Apna userId register karo (private room)
socket.emit('register', 'user1');

// QR receive karo
socket.on('qr', (data) => {
  console.log(data.qr); // Base64 image - show in <img> tag
});

// Connected notification
socket.on('session_status', (data) => {
  console.log(data.status); // 'connected', 'disconnected', etc.
});
```

---

### 4. Session Status
```http
GET /api/session/status
Authorization: Bearer YOUR_TOKEN
```
Response:
```json
{
  "status": "connected",  // "not_found" | "initializing" | "qr_ready" | "connected" | "disconnected"
  "hasQR": false
}
```

---

### 5. Send Single Message
```http
POST /api/messages/send
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "phone": "919876543210",
  "message": "Hello from TechAtire!"
}
```

---

### 6. Send Bulk Messages (with delay system)
```http
POST /api/messages/send-bulk
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "messages": [
    { "phone": "919876543210", "message": "Hello User 1" },
    { "phone": "919876543211", "message": "Hello User 2" },
    ...500 messages
  ]
}
```
Response:
```json
{
  "success": true,
  "queued": 500,
  "sentToday": 0,
  "remainingToday": 3000,
  "info": "Sending in batches of 20 with 10-15s delay between batches"
}
```

**Delay logic:**
- 20 messages bhejega (1s interval)
- 10-15 second random delay
- Firse 20 messages
- Aise continue jab tak queue khatam na ho

---

### 7. Queue Status
```http
GET /api/messages/queue-status
Authorization: Bearer YOUR_TOKEN
```
Response:
```json
{
  "queueLength": 480,
  "processing": true,
  "sentToday": 20,
  "remainingToday": 2980,
  "dailyLimit": 3000,
  "stats": { "total": 20, "success": 19, "failed": 1 },
  "config": { "batchSize": 20, "delayMin": "10s", "delayMax": "15s" }
}
```

---

### 8. Clear Queue
```http
DELETE /api/messages/clear-queue
Authorization: Bearer YOUR_TOKEN
```

---

### 9. Disconnect WhatsApp
```http
POST /api/session/disconnect
Authorization: Bearer YOUR_TOKEN
```

---

## Phone Number Format
- India: `919876543210` (91 + 10 digit number)
- No +, no spaces, no dashes
- Example: `+91 98765 43210` → `919876543210`

---

## Security Notes
- Har user ka JWT token alag hai
- WhatsApp sessions physically alag folders me store hote hain (`sessions/user_USER_ID/`)
- Socket.io rooms ensure karte hain ki QR sirf sahi user ko mile
- Production me MongoDB/PostgreSQL se users store karo

---

## Troubleshooting

### Puppeteer error on Railway
`nixpacks.toml` already configured hai. Agar error aaye:
- Railway Dashboard → Settings → Environment Variables
- Add: `PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true`

### Session lost after redeploy
Railway me persistent disk add karo:
- Dashboard → Add Volume → Mount path: `/app/sessions`
